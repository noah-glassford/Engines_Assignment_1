#include "RandomScale.h"
#include <random>




float RandomScale::RandomFloat()
{
	return 1;
}
