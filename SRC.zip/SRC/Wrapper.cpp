#include "Wrapper.h"
#include "RandomScale.h"

RandomScale RandomScaleObject;


PLUGIN_API float RandomFloat()
{
	return RandomScaleObject.RandomFloat();
}
