#pragma once

#ifndef __GAME_OBJECT__
#define __GAME_OBJECT__

#include "PluginSettings.h"
#include "Vector3D.h"



	class PLUGIN_API RandomScale
	{
	public:

		float RandomFloat();

	};

#endif
