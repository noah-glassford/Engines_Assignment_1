// Plugin.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

int main()
{
    /*
    GameObject gameObject;

    gameObject.SetID(1);
    gameObject.SetPosition(100.f, 100.f);

    std::cout << "The Game Object's ID is: " << gameObject.GetID() << std::endl;
    std::cout << "The Game Object's Position is: " << gameObject.GetPosition().x << ", " << gameObject.GetPosition().y  << std::endl;
    */
}

